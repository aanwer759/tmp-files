# Latest release available [here](https://github.com/tusc/wireguard-kmod/releases)
